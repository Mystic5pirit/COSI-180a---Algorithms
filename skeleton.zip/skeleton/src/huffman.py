'''
huffman .py

This module provides Huffman compression functionality that can be used by compression and decompression.
'''

import struct
import itertools

class Node:
	__slots__ = ("freq", "min_sym", "sym", "left", "right", "uid")
	_ids = itertools.count()
	
	def __init__(self, freq, sym=None, left=None, right=None):
		pass
		#TODO: Initialize Node; either leaf or internal
		#TODO: set min_sym based on node type (leaf or internal)
	
	def __lt__(self, other):
		pass
		#TODO: Implement less-than with comparison order kept
		
def build_tree(freqs):
	pass
	#TODO: Build the Huffman tree from the frequency counts
	
def derive_codes(root, freqs):
	pass
	#TODO: Derive the Huffman codes from Huffman tree
	def dfs(node, code_string):
		pass
		#TODO: Implement DFS to derive the codes

def count_frequencies(path):
	CHUNK_SIZE = 1 << 20  # 1 to power of 20 bytes (1MB)
	pass
	#TODO: Count the frequencies of the bytes in the file

# Helper functions
# Do not modify these functions
def write_u64be(f, n):
	f.write(struct.pack(">Q", n))

def write_u32be(f, n):
	f.write(struct.pack(">I", n))

def read_u64be(f):
	return struct.unpack(">Q", f.read(8))[0]

def read_u32be(f):
	return struct.unpack(">I", f.read(4))[0]
   
def write_compressed_data(in_path, codes, fout):
	CHUNK_SIZE = 1 << 20
	bitbuf = 0
	bitcount = 0
	with open(in_path, "rb") as fin:
		while True:
			chunk = fin.read(CHUNK_SIZE)
			if not chunk:
				break
			for b in chunk:
				code_string = codes[b]
				for i in range(len(code_string)):
					bit = int(code_string[i])
					bitbuf = (bitbuf << 1) | bit
					bitcount += 1
					if bitcount == 8:
						fout.write(bytes([bitbuf & 0xFF]))
						bitbuf = 0
						bitcount = 0
	if bitcount > 0:
		bitbuf <<= (8 - bitcount)
		fout.write(bytes([bitbuf & 0xFF]))

def read_compressed_data(f, root, size, out):
	if size == 0 or root is None:
		return
	if root.sym is not None:
		block = bytes([root.sym]) * min(size, 1_048_576)
		remain = size
		while remain > 0:
			n = min(remain, len(block))
			out.write(block[:n])
			remain -= n
		return
	node = root
	bytes_written = 0   
	remaining = size
	while remaining > 0:
		byte = f.read(1)
		if not byte:
			cur = 0
		else:
			cur = byte[0]
		for bitpos in range(7, -1, -1):
			bit = (cur >> bitpos) & 1
			node = node.right if bit else node.left
			if node.sym is not None:
				out.write(bytes([node.sym]))
				remaining -= 1
				bytes_written += 1
				if remaining == 0:
					return
				node = root
	return

def decompress_file(in_path, out_path, magic, file_type_name):
	with open(in_path, "rb") as f:
		head = f.read(4)
		if head != magic:
			raise ValueError("Bad magic: expected 'ANT0'")
		size = read_u64be(f)
		freqs = [read_u32be(f) for _ in range(256)]
		root = build_tree(freqs)
		with open(out_path, "wb") as out:
			read_compressed_data(f, root, size, out)
			
def compress_file(in_path, out_path, magic, file_type_name, chunk_size=1 << 20):
	freqs, total_size = count_frequencies(in_path)
	root = build_tree(freqs)
	codes = derive_codes(root, freqs)
	with open(out_path, "wb") as fout:
		fout.write(magic)
		write_u64be(fout, total_size)
		for i in range(256):
			write_u32be(fout, freqs[i])
		write_compressed_data(in_path, codes, fout)