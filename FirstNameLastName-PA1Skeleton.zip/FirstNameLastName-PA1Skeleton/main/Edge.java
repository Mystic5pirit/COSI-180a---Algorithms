package main;
public class Edge {
    private int id;
    private String startVertexLabel;
    private String destVertexLabel;
    private int startVertexID;
    private int destVertexID;
    private int length;
    private int angle;
    private String direction;
    private String code;
    private String name;

    public Edge(int id, String startVertexLabel, String destVertexLabel, int startVertexID, int destVertexID, int length, int angle, String direction, String code, String name) {
        this.id = id;
        this.startVertexLabel = startVertexLabel;
        this.destVertexLabel = destVertexLabel;
        this.startVertexID = startVertexID;
        this.destVertexID = destVertexID;
        this.length = length;
        this.angle = angle;
        this.direction = direction;
        this.code = code;
        this.name = name;
    }

    public Double priority(boolean optimizingTime) {
        return null;
    }

    public int getStart() {
        return this.startVertexID;
    }

    public int getDest() {
        return this.destVertexID;
    }

    public int getAngle() {
        return this.angle;
    }

    public String getDir() {
        return this.direction;
    }

    public String getName() {
        return this.name;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return String.format(
            "%d - (%d,%d) [%s -> %s] %s", 
            id, startVertexID, destVertexID, 
            startVertexLabel, destVertexLabel, name
        );
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Edge) {
            Edge other = (Edge) o;
            return id == other.id;
        }
        return false;
    }
}
