/**
 * This class represents a text based Map application.
 * It provides a way to find the shortest/fastest path between two locations on Brandeis campus
 */
package main;

import java.io.File;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.Scanner;

import datastructures.HashTable;
import datastructures.MinHeap;

public class Map {
    private final static String vertexPath = "MapDataVertices.txt";
    private final static String edgePath = "MapDataEdges.txt";
    private Graph graph;
    public static void main(String[] args) throws FileNotFoundException {
        new Map().run();
    }

    /**
     * Initializes an instance of Map with a graph representation of all campus locations and paths
     */
    public Map() throws FileNotFoundException {
        Vertex[] vertices = getVertexData();
        Edge[] edges = getEdgeData();  
        this.graph = new Graph(vertices, edges);
    }

    /**
     * Runs the Map application using input from the console
     */
    private void run() throws FileNotFoundException {
        Vertex[] vertices = graph.getVertices();
        ConsoleIO console = new ConsoleIO(mapVertexLabelToIndex(vertices));
        int start = console.getStartVertex();
        int destination;
        boolean optimizingTime, usePrims;
        while (start != -1) {
            destination = console.getDestinationVertex(start);
            optimizingTime = console.getPriorityMetric();
            if (destination == -1) {
                usePrims = console.getPrims();
                Graph minimumSpanningTree = minimumSpanningTree(usePrims, optimizingTime);
                Edge[] tour = preorderTraversal(minimumSpanningTree, start);
                Edge[] tempTour = replaceSuccessiveEdges(tour, optimizingTime);
                while (totalPriority(tempTour, optimizingTime) < totalPriority(tour, optimizingTime)) {
                    tour = tempTour;
                    tempTour = replaceSuccessiveEdges(tour, optimizingTime);
                }
                console.outputTour(tour, minimumSpanningTree, vertices);
                writeOutput(tour);
            } else {
                Edge[] path = dijkstra(start, destination, optimizingTime);
                console.outputPath(path, vertices);
                writeOutput(path);
            }
            start = console.getStartVertex();
        }
    }

    /**
     * @return Vertex array that holds every map location (including map corners and test vertex)
     * @throws FileNotFoundException if there is no file associated with the vertexPath variable
     */
    private Vertex[] getVertexData() throws FileNotFoundException {
        Vertex[] result = new Vertex[10];
        Scanner reader = new Scanner(new File(vertexPath));
        int index = 0;
        String temp;
        while (reader.hasNextLine()) {
            temp = reader.nextLine();
            if (temp.startsWith(String.valueOf(index))) {
                String[] arguments = temp.split(" ", 5);
                int id = Integer.parseInt(arguments[0]);
                String label = arguments[1];
                int x = Integer.parseInt(arguments[2]);
                int y = Integer.parseInt(arguments[3]);
                int nameSize = arguments[4].length();
                String name = arguments[4].substring(1, nameSize-1);

                result[index++] = new Vertex(id, label, x, y, name);
                if (index >= result.length) {
                    Vertex[] tempVertices = result;
                    result = new Vertex[index * 2];
                    for (int i = 0; i < index; i++) {
                        result[i] = tempVertices[i];
                    }
                }
            }
        }
        reader.close();
        if (index == result.length) return result;
        Vertex[] tempVertices = result;
        result = new Vertex[index];
        for (int i = 0; i < index; i++) {
            result[i] = tempVertices[i];
        }
        return result;
    }

    /**
     * @return Edge array that holds every path between two map locations (including map boundaries)
     * @throws FileNotFoundException if there is no file associated with the edgePath variable
     */
    private Edge[] getEdgeData() throws FileNotFoundException {
        Edge[] edges = new Edge[10];
        Scanner reader = new Scanner(new File(edgePath));
        int index = 0;
        String temp;
        while (reader.hasNextLine()) {
            temp = reader.nextLine();
            if (temp.startsWith(String.valueOf(index))) {
                String[] arguments = temp.split(" ", 10);
                int id  = Integer.parseInt(arguments[0]);
                String startVertexLabel = arguments[1];
                String destVertexLabel = arguments[2];
                int startVertexIndex = Integer.parseInt(arguments[3]);
                int destVertexIndex = Integer.parseInt(arguments[4]);
                int length = Integer.parseInt(arguments[5]);
                int angle = Integer.parseInt(arguments[6]);
                String direction = arguments[7];
                String code = arguments[8].substring(1, 2);
                int nameSize = arguments[9].length();
                String name = arguments[9].substring(1, nameSize-1);
                edges[index++] = new Edge(id, startVertexLabel, destVertexLabel, startVertexIndex, destVertexIndex, length, angle, direction, code, name);
                if (index >= edges.length) {
                    Edge[] tempEdges = edges;
                    edges = new Edge[index * 2];
                    for (int i = 0; i < index; i++) {
                        edges[i] = tempEdges[i];
                    }
                }
            }
        }
        reader.close();
        return edges;
    }

    /**
     * @param vertices a Vertex array of every possible map location
     * @return a HashTable that maps vertex labels to their associated id
     */
    private HashTable<String, Integer> mapVertexLabelToIndex(Vertex[] vertices) {
        HashTable<String, Integer> result = new HashTable<String, Integer>();
        for (Vertex v : vertices) {
            result.put(v.getLabel(), v.getId());
        }
        return result;
    }

    /**
     * @param route an Edge array representing a route on the campus
     * @param optimizingTime whether to use time or distance
     * @return the total time/distance of the route
     */
    private double totalPriority(Edge[] route, boolean optimizingTime) {
        double totalPriority = 0;
        for (Edge edge : route) {
            if (edge != null) totalPriority += edge.priority(optimizingTime);
        }
        return totalPriority;
    }

    /**
     * @param route a path/tour of the brandeis campus
     * Writes output to Route.txt, RouteCropped.txt, and RouteEdges.txt
     * @throws FileNotFoundException if any of the three output files do not support a PrintWriter
     */
    public void writeOutput(Edge[] route) throws FileNotFoundException {
        Vertex[] vertices = graph.getVertices();
        int MapWidthFeet = 5521;
        int MapHeightFeet = 4369;
        int MapWidthPixels = 2528;
        int MapHeightPixels = 2000;
        int CropLeft = 150;
        int CropDown = 125;
        PrintWriter routeWriter = new PrintWriter("Route.txt");
        PrintWriter routeCroppedWriter = new PrintWriter("RouteCropped.txt");
        PrintWriter routeEdgesWriter = new PrintWriter("RouteEdges.txt");
        for (Edge edge : route) {
            int a = vertices[edge.getStart()].getX() * MapHeightPixels / MapHeightFeet;
            int b = vertices[edge.getStart()].getY() * MapWidthPixels / MapWidthFeet;
            int c = vertices[edge.getDest()].getX() * MapHeightPixels / MapHeightFeet;
            int d = vertices[edge.getDest()].getY() * MapWidthPixels / MapWidthFeet;
            routeWriter.printf("%d %d %d %d%n", a, b, c, d);
            a -= CropLeft;
            b -= CropDown;
            c -= CropLeft;
            d -= CropDown;
            routeCroppedWriter.printf("%d %d %d %d%n", a, b, c, d);
            routeEdgesWriter.println(edge);
        }
        routeWriter.close();
        routeCroppedWriter.close();
        routeEdgesWriter.close();
    }

    /**
     * @param usePrims whether to use Prims or Kruskals MST algorithm
     * @param optimizingTime whether the MST is minimal with respect to time or distance
     * @return
     */
    public Graph minimumSpanningTree(boolean usePrims, boolean optimizingTime) {
        if (usePrims) {
            return minimumSpanningTreePrims(optimizingTime);
        } 
        return minimumSpanningTreeKruskals(optimizingTime);
    }

    /**
     * @param optimizingTime whether the MST is minimal with respect to time or distance
     * @return a Graph representing an undirected MST of the campus graph (excluding map corners and test vertex)
     */
    private Graph minimumSpanningTreeKruskals(boolean optimizingTime) {
        return null;
    }

    /**
     * @param optimizingTime whether the MST is minimal with respect to time or distance
     * @return a Graph representing an undirected MST of the campus graph (excluding map corners and test vertex)
     */
    private Graph minimumSpanningTreePrims(boolean optimizingTime) {
        return null;
    }

    /**
     * @param tree a Graph representing a MST of the campus graph
     * @param startVertexID the root of the tree
     * @return an Edge array representing a preorder traversal of tree starting at startVertexID
     */
    public Edge[] preorderTraversal(Graph tree, int startVertexID) {
        return null;
    }

    /**
     * @param tour a tour of the campus that visits every vertex at least once
     * @param optimizingTime whether the tour minimizing time or distance
     * @return a tour in which successive edges are greedily replaced with a single edge 
     * if it is faster/shorter and still reaches every vertex at least once
     */
    public Edge[] replaceSuccessiveEdges(Edge[] tour, boolean optimizingTime) {
        return null;
    }

    /**
     * @param start the vertexId associated with the starting vertex
     * @param destination the vertexId associated with the destination vertex
     * @param optimizingTime whether the path is minimizing time or distance
     * @return an Edge array representing the fastest/shortest path to get from start to destination
     */
    public Edge[] dijkstra(int start, int destination, boolean optimizingTime) {
        return null;
    }
}