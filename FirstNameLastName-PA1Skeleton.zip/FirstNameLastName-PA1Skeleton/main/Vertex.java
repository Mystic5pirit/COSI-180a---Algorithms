package main;

public class Vertex {
    private int id;
    private String label;
    private int x;
    private int y;
    private String name;
    private Vertex parent;
    private int rank;

    public Vertex(int id, String label, int x, int y, String name) {
        this.id = id;
        this.label = label;
        this.x = x;
        this.y = y;
        this.name = name;
    }

    public void makeSet() {

    }

    public void union(Vertex y) {
        
    }

    public void link(Vertex y) {
        
    }

    public Vertex findSet() {
        return null;
    }

    @Override
    public String toString() {
        return "(" + label + ") " + name;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Vertex) {
            Vertex other = (Vertex) o;
            return id == other.id;
        }
        return false;
    }

    public String getLabel() {
        return label;
    }

    public int getId() {
        return id;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
